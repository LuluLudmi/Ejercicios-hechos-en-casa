//paquete
package Repasando;

import java.util.Scanner;

public class RepasandoJava {

    public static void main(String[] args) {

        /*5) Desarrollar un programa que permita ingresar un número N.Acto seguido,
        permitir ingresar N números.La computadora muestra cuál fue el mayor 
        y en qué orden aparecio. Ejemplo:
        Se ingresa 5, luego 4 8 6 7 5, la computadora muestra:
       "El mayor es el 8 en la 2° posición".
         */
        Scanner teclado = new Scanner(System.in);
//
//        int nNumero;
//      
//        int mayor = 0;
//
//        for (int i = 1; i <= 6; i++) {
//            System.out.println("Ingrese un numero N:");
//            nNumero = teclado.nextInt();
//
//            if (i == 1) {
//                nNumero = mayor;
//            }
//            if (nNumero > mayor) {
//                mayor = nNumero;
//            }
//        }
//        System.out.println("El n Numero mayor es:" + mayor);
//        
//        

        int nNumero;
        int nNumeross;
        int mayor = 0;
        String masNumeros="";
        
        
            System.out.println("Ingrese un numero N:");
            nNumero = teclado.nextInt();
            System.out.println("Ingrese un N numeros al azar:");
            nNumeross= teclado.nextInt();
            masNumeros= String.valueOf(nNumeross);
            for (int i = 0; i < masNumeros.length(); i++) {
                char c = masNumeros.charAt(i);
                System.out.print(c + " ");
                
               
                
                
                
            
        }
          

    }

}
