package vectoresejercicios;

import java.util.Scanner;

public class VectoresEjercicios {

    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Crear un vector que contenga el monto de la facturación total de una empresa
        de los últimos 6 meses
        informar:
        la máxima facturación
        la facturación más baja
        el promedio de facturación
         */
        Scanner teclado = new Scanner(System.in);
//        int[] facturacion = {1098, 2300, 2658, 2998, 38784, 10457, 60000, 14487, 651245, 467845, 351548, 104751};
//
//        int total = 0;
//        for (int i = 0; i < facturacion.length; i++) {
//            total += facturacion[i];
//        }
//
//        System.out.println("total:" + total);
//        System.out.println("promedio:" + ((float) total / facturacion.length));
//
//        int min = facturacion[0];
//        int max = facturacion[0];
//        for (int i = 1; i < facturacion.length; i++) {
//            if (facturacion[i] < min) {
//                min = facturacion[i];
//            }
//
//            if (facturacion[i] > max) {
//                max = facturacion[i];
//            }
//
//        }
//        System.out.println("Facturacion minima:" + min);
//        System.out.println("Facturacion maxima:" + max);

        /*
        Pedirle al usuario que ingrese el tamaño del vector (longitud)
        Luego pedirle al usuario que cargue los números de cada posición .
        Al finalizar, por pantalla mostrar:
            * Listado de números ingresados, uno al lado del otro separados por una barra.
            * Sumatoria de todos los números
            * Mayor número ingresado
            * Menor número ingresado
            * Promedio de números ingresados (entero, sin decimales)
            * Cantidad de números pares
            * Cantidad de números impares
         */
        // Solicitar el tamaño del vector
        System.out.print("Por favor,ingrese el tamaño del vector: ");
        int tamanio = teclado.nextInt();

        // Validar que el tamaño sea mayor que cero
        if (tamanio <= 0) {
            System.out.println("El tamaño del vector debe ser mayor que cero.");
            return;
        }

        // Crear el vector numeros
        int[] numeros = new int[tamanio];

        // Cargar los números en el vector numeros
        for (int i = 0; i < tamanio; i++) {
            System.out.print("Ingrese el número para la posición " + i + ": ");
            numeros[i] = teclado.nextInt();
        }

        // Listado de números ingresados
        System.out.println("El listado de números ingresados es:");
        for (int i = 0; i < tamanio; i++) {
            System.out.print("Posición " + i + ":" + numeros[i] + " " + "-" + " ");
        }
        System.out.println("Sumatoria  de todos los números:");
        double sumatoria = 0; // utilizo nuevamente un bucle for para sumar todos los elementos del vector.
        for (int i = 0; i < tamanio; i++) {
            sumatoria += numeros[i];
        }

        // Mostrar la suma
        System.out.println("Sumatoria de todos los números: " + sumatoria);
        System.out.println("promedio de los numeros ingresados:" + ((int) sumatoria / tamanio));

        System.out.println("Ahora se mostraran los minimos y maximos numeros ingresados:");

        int min = numeros[0];
        int max = numeros[0];
        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] < min) {
                min = numeros[i];
            }
            if (numeros[i] > max) {
                max = numeros[i];
            }
        }
        System.out.println("El menor número ingresado: " + min);
        System.out.println("El mayor número ingresado: " + max);

        int numPares = 0;
        int numImpares = 0;
        for (int i = 0; i < tamanio; i++) {
            if (numeros[i] % 2 == 0) {
                numPares++;
            } else {
                numImpares++;
            }

        }
        System.out.println("Cantidad de numeros pares: " + numPares);
        System.out.println("Cantidad de numeros impares: " + numImpares);
    }
}
