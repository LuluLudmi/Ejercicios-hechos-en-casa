
package While;

import java.util.Random;
import java.util.Scanner;

public class Clasewhile {
    public static void main(String[] args) {
        /* * El cliente debe ingresar los campos Usuario,
        Contraseña y Clave Token (todos obligatorios).
        * El campo Usuario no distingue minúsculas
        o mayúsculas.
        * El campo Contraseña es sensible a las
        minúsculas y mayúsculas.
        La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. 
	* Si alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicación deberá informar al
        usuario que debe dirigirse a la sucursal del
        banco más cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicación debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deberá informar que ha ingresado
        correctamente al Online Banking.
        */
        Scanner teclado = new Scanner(System.in);
        Random random = new Random ();
        int token = random.nextInt(900000) + 100000;
        String Usuario = "Toto";
        String contraseña = "01234";
        String usuarioCorrecto;
        String contraseñaCorrecta;
        int tokenDeBienvenida;
        
        System.out.println("Bienvenido a la  plataforma Online Banking, para ingresar siga las siguientes instrucciones:");
        System.out.println("Por favor,ingrese su Usuario:");
        Usuario = teclado.next();
        System.out.println("Por favor, ingrese su contraseña:");
        contraseña= teclado.next();
        
        do {
            System.out.println("Confirma tu usuario");
            usuarioCorrecto=teclado.next();
            if(!Usuario.equals(usuarioCorrecto)){
                System.out.println("Contraseñas distinta,ingrese la correcta:");
            }
        }while(!Usuario.equals(usuarioCorrecto));
        System.out.println("Ahora ingrese la contraseña");
       
    }
    
}
