/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase15gilmi;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Clase15Gilmi {
// Una tienda ofrece un descuento del 15% sobre el total de la compra durante
//el mes de octubre. Dado un mes y un importe, calcular cuál es la cantidad que
//se debe cobrar al cliente.

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //        System.out.println("Introduce el mes (del 1 al 12)");
        //        int mes = teclado.nextInt();
        //        System.out.println("Introduce el importe total de la compra:");
        //        double importe = teclado.nextDouble();
        //        double totalAPagar = importe;
        //        double descuento= 15;
        //
        //        if (mes == 10) {
        //            totalAPagar = importe - (importe/100 * descuento);
        //            System.out.println("El porcentaje del descuento es %:"+ descuento);
        //        } else {
        //            totalAPagar = importe;
        //        }
        //        String totalAPagarRedondeado = String.format("%.2f",totalAPagar);
        //       
        //        System.out.println("El total a cobrar al cliente es:"+ totalAPagarRedondeado);

        /*  2) Crear un programa que pida al usuario un número y un símbolo, y 
            dibuje un cuadrado usando ese símbolo. El cuadrado tendrá el tamaño que ha indicado el usuario. Por ejemplo, 
        si el usuario introduce 4 como tamaño y * como símbolo, deberá escribirse algo como:
      ****
      ****
      ****
      *****
         */
        //        System.out.println("Introduce el tamaño del cuadrado:");
        //        int tamanio = teclado.nextInt();
        //        System.out.println("Introduce el simbolo para dibujar el cuadrado:");
        //        String simbolo=teclado.next();
        //        for (int i=0; i<tamanio; i++){  // 1er for repite lo que imprimio el 2do for
        //            for(int j=0; j<tamanio; j++){ // 2do imprime el simbolo elegido
        //                System.out.print(simbolo); //print imprime sin salto de linea
        //            }
        //            System.out.println();
        //        }
        //        3) Se pide representar el algoritmo que nos calcule la suma 
        //         de los N primeros números naturales. N se leerá por teclado.
        //         Ejemplo, si ingresamos 4, hacer: 1+2+3+4 = 10
        //        int suma = 0;
        //        System.out.println("Ingrese un numero:");
        //        int numero = teclado.nextInt();
        //
        //        for (int i = 1; i <= numero; i++) {
        //            suma += i;
        //        }
        //System.out.println("La suma de los numeros natutrales es:" + suma);
        //        4) Crear un programa que visualice la cuenta de los números que son 
        //        múltiplos de 2 o de 3 que hay entre 1 y 100.
        //        int contadorDeNumerosMultiplosDe2yDe3 = 0;
        //        
        //        for (int i = 1; i <= 100; i++) {
        //            if (i % 3 == 0 || i % 2 == 0) {
        //                // representa el resto de la division
        //                System.out.println();
        //               contadorDeNumerosMultiplosDe2yDe3 ++;
        //            } 
        //        }
        //         System.out.println("La cantidad de numeros que son multiplos de 2 o  de"
        //                 + "que hay entre 1 y 100 son:"
        //                 + contadorDeNumerosMultiplosDe2yDe3);
        //        5) Desarrollar un programa que permita ingresar un número N.
        //       Acto seguido, permitir ingresar N números.La computadora muestra cuál fue el mayor 
        //      y en qué orden apareció
        //        Ejemplo:
        //        Se ingresa 5, luego 4 8 6 7 5, la computadora muestra:
        //        "El mayor es el 8 en la 2° posición".
        //        System.out.println("Cuantos numeros desea ingresar:");
        //        int cantidadDeNumeros = teclado.nextInt();
        //        int numeroGrande = Interger.MIN_VALUE;
        //        int posicionGrande = 0;
        //        for (int i = 1; i < cantidadDeNumeros; i++) {
        //            System.out.println("Ingrese un numero:");
        //            int numeroNuevo = teclado.nextInt();
        //            if (numeroNuevo > numeroGrande) {
        //
        //                numeroGrande = numeroNuevo;
        //                posicionGrande = i;
        //            }
        //
        //        }
        //        System.out.println("El mayor numero es: " + numeroGrande + " en la "
        //                + posicionGrande + " posicion.");

        /*
        6) Desarrollar un programa que permita ingresar un número natural. 
        La computadora muestra el factorial del número. Ejemplo: Se ingresa 5,
        la computadora muestra: 120.
         */
        //        System.out.println("Por favor ingrese un numero natural");
        //        int numeroNatural = teclado.nextInt();
        //        int factorial = 1;
        //        for (int i = 1; i <= numeroNatural; i++) {
        //            factorial *= i; // multiplicacion y asignacion        
        //        }
        //        System.out.println("El  factorial del numero ingresado es " + factorial);
        //      7 ) Crear un algoritmo (y su correspondiente diagrama de flujo) 
        //       que lea números enteros hasta teclear 0, y nos muestre el máximo, 
        //       el mínimo (sin considerar el 0) y la media (promedio) de todos ellos.
        /* System.out.println("Ingrese los numeros enteros:");
        int numerosE = teclado.nextInt();
        int numeroMaximo = Interger.MIN_VALUE;
        int numeroMinimo = Interger.MAX_VALUE;
        int suma = 0;
        double promedio = 0;

        for (int i = 1; i <= numerosE; i++) {
            int numeroNuevo = teclado.nextInt();
            if(i ==1){
                numeroMaximo = numeroNuevo;
                numeroMinimo=numeroNuevo;
            }
            if (numeroNuevo > numeroMaximo) {
                numeroMaximo = numeroNuevo;
            } 
            if(numeroNuevo < numeroMinimo){
                numeroMinimo = numeroNuevo;
            }
            
            suma = suma + numeroNuevo;
            promedio=(double)suma/numerosE;
            
        }

        System.out.println("El maximo numero es: " + numeroMaximo);
        System.out.println("El minimo numero es: " + numeroMinimo);
        System.out.println("La suma de todos los numeros enteros es:" + suma);
        System.out.println("El promedio es:"+ promedio);
        
        
       8) Leer tres números que denoten una fecha (día, mes, año). Comprobar que
        es una fecha válida. Si no es válida escribir un mensaje de error. Si es válida
        escribir la fecha cambiando el número del mes por su nombre. Ej. si se 
        introduce 1 2 2006, se deberá imprimir “1 de febrero de 2006”. El año debe ser
        mayor que 0. 
       
       
        System.out.println("Ingrese el dia:");
        int dia= teclado.nextInt();
        System.out.println("Ingrese el mes:");
        int mes= teclado.nextInt();
         System.out.println("Ingrese el año:");
        int anio= teclado.nextInt();
        String mesDelAño= null; // valor vacio o nulo
        String msj= "de";
        String espacio= " ";
        switch (mes){
            case 1:
                mesDelAño = "Enero";
                break;
                case 2:
                mesDelAño = "Febrero";
                break;
                case 3:
                mesDelAño = "Marzo";
                break;
                case 4:
                mesDelAño = "Abril";
                break;
                case 5:
                mesDelAño = "Mayo";
                break;
                case 6:
                mesDelAño = "Junio";
                break;
                case 7:
                mesDelAño = "Julio";
                break;
                case 8:
                mesDelAño = "Agosto";
                break;
                case 9:
                mesDelAño = "Septiembre";
                break;
                case 10:
                mesDelAño = "Octubre";
                break;
                case 11:
                mesDelAño = "Noviembre";
                break;
                case 12:
                mesDelAño = "Diciembre";
                break;
                default:
                    System.out.println("Numero del mes, incorrecto:");
        }
        
        System.out.println(dia + " "+"de" + " "+  mesDelAño + " "+ "de"+" " +  anio);
        
        9) Imprimir la siguiente figura utilizando la estructura for  
                : @@@@
         
       
        System.out.println("Introduce la longitud del simbolo:");
        int longitud = teclado.nextInt();
        System.out.println("Introduce el simbolo ha imprimir:");
        String simbolo = teclado.next();
        for (int i = 0; i < longitud; i++) {  // 1er for repite lo que imprimio el 2do for
            for (int j = 0; j <= longitud; j++) { // 2do imprime el simbolo elegido
                continue;
            }

            System.out.print(simbolo);

        }
        12) Imprimir la siguiente figura utilizando la estructura for  
        : @@@@@
        @@@@
        @@@
        @@
        @
         */
        System.out.println("Introduce el tamaño del cuadrado:");
        int tamanio = teclado.nextInt();
        System.out.println("Introduce el simbolo para dibujar el cuadrado:");
        String simbolo = teclado.next();
        for (int i = 0; i < tamanio; i++) {  // 1er for repite lo que imprimio el 2do for
               tamanio --;
            for (int j = 0; j < tamanio; j++) { // 2do imprime el simbolo elegido
            
                System.out.print(simbolo); //print imprime sin salto de linea
            }
            System.out.println();
        }
    }

}
