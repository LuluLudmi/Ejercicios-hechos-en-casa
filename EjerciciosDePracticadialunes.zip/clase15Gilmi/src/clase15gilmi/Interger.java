/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clase15gilmi;

/**
 *
 * @author alumno
 */
class Interger {

    static int MIN_VALUE;
    static int MAX_VALUE;
    
}
