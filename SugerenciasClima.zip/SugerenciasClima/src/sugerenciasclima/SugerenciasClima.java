package sugerenciasclima;

import java.util.Scanner;

public class SugerenciasClima {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
         /*
        Ejercicio 2:
        Dada la siguiente tabla del tiempo, hacer un
        programa que indique qué puede hacer una
        persona con dicho pronóstico:
        
        Temperatura     Tiempo      Sugerencia
        > 25°           Soleado     Caminar y tomar sol
        > 15° y <=25°   Soleado     Caminar
        <=15°           Soleado     Caminar con campera
        <10°            Lluvia      Quedarse en casa o salir con paraguas y campera
        <10°            Nieve       Esquiar
        
        Luego pedirle al usuario que ingrese una temperatura y una condición
        del tiempo válida (Soleado, lluvia o nieve) e indicarle la sugerencia.
         */
// ver videos de youtube https://www.youtube.com/watch?v=YSLWr8-4Rmk

        System.out.print("Ingrese la temperatura: ");
        int temperatura = teclado.nextInt();
        teclado.nextLine(); // Consumiendo el salto de línea

        System.out.print("Ingrese la condición del tiempo (Soleado, Lluvia, Nieve): ");
        String tiempo = teclado.nextLine();

        String sugerencia = obtenerSugerencia(temperatura, tiempo);
        System.out.println(sugerencia);

        teclado.close();
       
    }

    public static String obtenerSugerencia(int temperatura, String tiempo) {
        if (tiempo.equalsIgnoreCase("Soleado")) {
            if (temperatura > 25) {
                return "Caminar y tomar sol";
            } else if (temperatura > 15 && temperatura <= 25) {
                return "Caminar";
            } else { // <= 15
                return "Caminar con campera";
            }
        } else if (tiempo.equalsIgnoreCase("Lluvia")) {
            if (temperatura < 10) {
                return "Quedarse en casa o salir con paraguas y campera";
            }
        } else if (tiempo.equalsIgnoreCase("Nieve")) {
            if (temperatura < 10) {
                return "Esquiar";
            }
        }

        return "No hay sugerencia disponible para las condiciones ingresadas.";
    }

}
